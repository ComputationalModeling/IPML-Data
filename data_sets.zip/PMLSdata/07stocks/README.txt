File djiweekly.mat contains variable djiweekly with closing values of Dow Jones
Industrial Average on 4223 consecutive weeks.

File djiweekly.csv contains the same data in column 1.
