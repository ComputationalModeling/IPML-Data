shotNoise.mat:
	Variable A gives the arrival times of 290 photon absorption events in an
	avalanche photodiode detector.

Time is measured in units of 50ns. Total duration is 5s. 

shotNoise.txt, shotNoise.npy: Same data.

Data courtesy J F Beausang.
