Jean Perrin's data on Brownian motion.
(x,y) values of endpoints of 508 random walks, in micrometers.

Data from J. Perrin, "Les Atomes."
